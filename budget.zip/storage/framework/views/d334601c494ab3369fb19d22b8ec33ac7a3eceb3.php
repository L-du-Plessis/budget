<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Display income card -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header p-1 pl-3"><h5>Income</h5></div>

                <div class="card-body">
                    <form method="post" action="/addIncome">
                    <?php echo e(csrf_field()); ?>

                    
                    <!-- Display income table header -->
                    <table class="table table-striped table-sm mb-0">
                      <tr>
                        <th>Description</th>
                        <th width='15%' class="text-right">Amount</th>
                        <th>Comment</th>
                        <th width="15px"></th>
                        <th width="15px"></th>
                      </tr>
                      
                      <!-- Populate income table -->
                      <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($income_id == $income->id): ?>
                          <tr>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm" id="income_description" name="income_description" value="<?php echo e($income->income_description); ?>"></td>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm text-right" id="income_amount" name="income_amount" value="<?php echo e($income->income_amount); ?>"></td>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm" id="income_comment" name="income_comment" value="<?php echo e($income->income_comment); ?>"></td>
                            <td><input type="hidden" id="income_oldid" name="income_oldid" value="<?php echo e($income->id); ?>"></td>
                            <td class="p-0 align-middle"><button type="submit" class="btn btn-link p-0" title="Update record"><i class="far fa-check-square fa-2x text-success"></i></button></td>
                          </tr>
                        <?php else: ?>
                          <tr>
                            <td><?php echo e($income->income_description); ?></td>
                            <td class="text-right"><?php echo e(number_format($income->income_amount, 2)); ?></td>
                            <td><?php echo e($income->income_comment); ?></td>
                            <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" title="Edit record"><a href="/edit/<?php echo e($income->id); ?>/0"><i class="fas fa-edit fa-lg text-primary"></i></a></button></td>
                            <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" title="Delete record"><a href="/delete/<?php echo e($income->id); ?>/0"><i class="far fa-trash-alt fa-lg text-danger"></i></a></button></td>
                          </tr>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      <!-- Display income total -->
                      <tr>
                        <td></td>
                        <td class="font-weight-bold text-right"><?php echo e(number_format($income_total, 2)); ?></td>
                        <td colspan="3"></td>
                      </tr>      
      
                      <!-- Display new income record fields -->
                      <?php if(!$income_id): ?>
                        <tr>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm" id="income_description" name="income_description" value="<?php echo e(old('income_description')); ?>"></td>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm text-right" id="income_amount" name="income_amount" value="<?php echo e(old('income_amount')); ?>"></td>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm" id="income_comment" name="income_comment" value="<?php echo e(old('income_comment')); ?>"></td>
                          <td></td>
                          <td class="p-0 align-middle"><button type="submit" class="btn btn-link p-0" title="Add record"><i class="far fa-plus-square fa-2x text-success"></i></button></td>
                        </tr>
                      <?php endif; ?>
                    </table>
                    
                    <!-- Display income errors -->
                    <?php if($errors->has('income_description') || $errors->has('income_amount')): ?>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="mt-1 mb-0 text-danger"><?php echo e($error); ?></p>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Display expenses card -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header p-1 pl-3"><h5>Expenses</h5></div>

                <div class="card-body">
                    <form method="post" action="/addExpense">
                    <?php echo e(csrf_field()); ?>

                    
                    <!-- Display expenses table header -->
                    <table class="table table-striped table-sm mb-0">
                      <tr>
                        <th>Description</th>
                        <th width='15%' class="text-right">Amount</th>
                        <th>Comment</th>
                        <th width="15px"></th>
                        <th width="15px"></th>
                      </tr>
                      
                      <!-- Populate expenses table -->
                      <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($expense_id == $expense->id): ?>
                          <tr>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm" id="expense_description" name="expense_description" value="<?php echo e($expense->expense_description); ?>"></td>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm text-right" id="expense_amount" name="expense_amount" value="<?php echo e($expense->expense_amount); ?>"></td>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm" id="expense_comment" name="expense_comment" value="<?php echo e($expense->expense_comment); ?>"></td>
                            <td><input type="hidden" id="expense_oldid" name="expense_oldid" value="<?php echo e($expense->id); ?>"></td>
                            <td class="p-0 align-middle"><button type="submit" class="btn btn-link p-0" title="Update record"><i class="far fa-check-square fa-2x text-success"></i></button></td>
                          </tr>
                        <?php else: ?>
                          <tr>
                            <td><?php echo e($expense->expense_description); ?></td>
                            <td class="text-right"><?php echo e(number_format($expense->expense_amount, 2)); ?></td>
                            <td><?php echo e($expense->expense_comment); ?></td>
                            <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" title="Edit record"><a href="/edit/0/<?php echo e($expense->id); ?>"><i class="fas fa-edit fa-lg text-primary"></i></a></button></td>
                            <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" title="Delete record"><a href="/delete/0/<?php echo e($expense->id); ?>"><i class="far fa-trash-alt fa-lg text-danger"></i></a></button></td>
                          </tr>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      <!-- Display expenses total -->
                      <tr>
                        <td></td>
                        <td class="font-weight-bold text-right"><?php echo e(number_format($expense_total, 2)); ?></td>
                        <td colspan="3"></td>
                      </tr>
      
                      <!-- Display new expense record fields -->
                      <?php if(!$expense_id): ?>
                        <tr>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm" id="expense_description" name="expense_description" value="<?php echo e(old('expense_description')); ?>"></td>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm text-right" id="expense_amount" name="expense_amount" value="<?php echo e(old('expense_amount')); ?>"></td>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm" id="expense_comment" name="expense_comment" value="<?php echo e(old('expense_comment')); ?>"></td>
                          <td></td>
                          <td class="p-0 align-middle"><button type="submit" class="btn btn-link p-0" title="Add record"><i class="far fa-plus-square fa-2x text-success"></i></button></td>
                        </tr>
                      <?php endif; ?>
                    </table>
                    
                    <!-- Display expense errors -->
                    <?php if($errors->has('expense_description') || $errors->has('expense_amount')): ?>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="mt-1 mb-0 text-danger"><?php echo e($error); ?></p>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>