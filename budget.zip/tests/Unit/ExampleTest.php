<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

use App\Expenses;


class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function testBasicTest()
    {
        //$this->assertTrue(true);
        
        /*
        $expenses = Expenses::orderBy('expense_amount', 'desc')->get();
        $record = Expenses::where('id', '!=', '0')->first();
        */
        
        //dd($expenses);
        //dd($record);

        //$this->assertCount(4, $expenses);
        
        /*
        $this->assertEquals([
            [
                'year' => $record->created_at->format('Y'),
                'month' => $record->created_at->format('F'),
            ]
        ], $expenses);
        */
    }
}
