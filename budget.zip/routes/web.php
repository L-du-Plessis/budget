<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::post('/addIncome', 'HomeController@storeIncome');
Route::post('/addExpense', 'HomeController@storeExpense');
Route::get('/edit/{income_id}/{expense_id}', 'HomeController@index');
Route::get('/delete/{income_id}/{expense_id}', 'HomeController@destroy');
