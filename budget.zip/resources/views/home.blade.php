@extends('layouts.app')

@section('content')
<div class="container-fluid">
    @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
    @endif

    <div class="row">
        <!-- Display income card -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header p-1 pl-3"><h5>Income</h5></div>

                <div class="card-body">
                    <form id="formIncome" method="POST" action="/home/income">
                    @if ($income_id)
                        @method('PATCH')
                    @endif
                    
                    @csrf
                    
                    <!-- Display income table header -->
                    <table class="table table-striped table-sm mb-0">
                      <tr>
                        <th>Description</th>
                        <th width='15%' class="text-right">Amount</th>
                        <th>Comment</th>
                        <th width="15px"></th>
                        <th width="15px"></th>
                      </tr>
                      
                      <!-- Populate income table -->
                      @foreach ($incomes as $income)
                        @if ($income_id == $income->id)
                          <tr>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm" id="income_description" name="income_description" value="{{ $income->income_description }}"></td>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm text-right" id="income_amount" name="income_amount" value="{{ $income->income_amount }}"></td>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm" id="income_comment" name="income_comment" value="{{ $income->income_comment }}"></td>
                            <td><input type="hidden" id="income_oldid" name="income_oldid" value="{{ $income->id }}"></td>
                            <td class="p-0 align-middle"><button type="submit" class="btn btn-link p-0" title="Update record"><i class="far fa-check-square fa-2x text-success"></i></button></td>
                          </tr>
                        @else
                          <tr>
                            <td>{{ $income->income_description }}</td>
                            <td class="text-right">{{ number_format($income->income_amount, 2) }}</td>
                            <td>{{ $income->income_comment }}</td>
                            <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" title="Edit record"><a href="/home/{{ $income->id }}/0/edit"><i class="fas fa-edit fa-lg text-primary"></i></a></button></td>
                            <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" data-toggle="modal" data-target="#deleteModal" onclick="deleteClicked({{ $income->id }}, 0)" title="Delete record"><i class="far fa-trash-alt fa-lg text-danger"></i></button></td>
                          </tr>
                        @endif
                      @endforeach
                      
                      <!-- Display income total -->
                      <tr>
                        <td></td>
                        <td class="font-weight-bold text-right">{{ number_format($income_total, 2) }}</td>
                        <td colspan="3"></td>
                      </tr>      
      
                      <!-- Display new income record fields -->
                      @if (!$income_id)
                        <tr>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm" id="income_description" name="income_description" value="{{ old('income_description') }}"></td>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm text-right" id="income_amount" name="income_amount" value="{{ old('income_amount') }}"></td>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm" id="income_comment" name="income_comment" value="{{ old('income_comment') }}"></td>
                          <td></td>
                          <td class="p-0 align-middle"><button type="submit" class="btn btn-link p-0" title="Add record"><i class="far fa-plus-square fa-2x text-success"></i></button></td>
                        </tr>
                      @endif
                    </table>
                    
                    <!-- Display income errors -->
                    @if ($errors->has('income_description') || $errors->has('income_amount'))
                      @foreach ($errors->all() as $error)
                        <p class="mt-1 mb-0 text-danger">{{ $error }}</p>
                      @endforeach
                    @endif
                    </form>
                </div>
            </div>
        </div>
        
        
        <!-- Display expenses card -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header p-1 pl-3"><h5>Expenses</h5></div>

                <div class="card-body">
                    <form id="formExpense" method="POST" action="/home/expense">
                    @if ($expense_id)
                        @method('PATCH')
                    @endif
                    
                    @csrf
                    
                    <!-- Display expenses table header -->
                    <table class="table table-striped table-sm mb-0">
                      <tr>
                        <th>Description</th>
                        <th width='15%' class="text-right">Amount</th>
                        <th>Comment</th>
                        <th width="15px"></th>
                        <th width="15px"></th>
                      </tr>
                      
                      <!-- Populate expenses table -->
                      @foreach ($expenses as $expense)
                        @if ($expense_id == $expense->id)
                          <tr>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm" id="expense_description" name="expense_description" value="{{ $expense->expense_description }}"></td>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm text-right" id="expense_amount" name="expense_amount" value="{{ $expense->expense_amount }}"></td>
                            <td class="bg-info"><input type="text" class="form-control form-control-sm" id="expense_comment" name="expense_comment" value="{{ $expense->expense_comment }}"></td>
                            <td><input type="hidden" id="expense_oldid" name="expense_oldid" value="{{ $expense->id }}"></td>
                            <td class="p-0 align-middle"><button type="submit" class="btn btn-link p-0" title="Update record"><i class="far fa-check-square fa-2x text-success"></i></button></td>
                          </tr>
                        @else
                          <tr>
                            <td>{{ $expense->expense_description }}</td>
                            <td class="text-right">{{ number_format($expense->expense_amount, 2) }}</td>
                            <td>{{ $expense->expense_comment }}</td>
                            <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" title="Edit record"><a href="/home/0/{{ $expense->id }}/edit"><i class="fas fa-edit fa-lg text-primary"></i></a></button></td>
                            <td class="p-0 align-middle"><button type="button" class="btn btn-link p-0" data-toggle="modal" data-target="#deleteModal" onclick="deleteClicked(0, {{ $expense->id }})" title="Delete record"><i class="far fa-trash-alt fa-lg text-danger"></i></button></td>
                          </tr>
                        @endif
                      @endforeach
                      
                      <!-- Display expenses total -->
                      <tr>
                        <td></td>
                        <td class="font-weight-bold text-right">{{ number_format($expense_total, 2) }}</td>
                        <td colspan="3"></td>
                      </tr>
      
                      <!-- Display new expense record fields -->
                      @if (!$expense_id)
                        <tr>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm" id="expense_description" name="expense_description" value="{{ old('expense_description') }}"></td>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm text-right" id="expense_amount" name="expense_amount" value="{{ old('expense_amount') }}"></td>
                          <td class="bg-info"><input type="text" class="form-control form-control-sm" id="expense_comment" name="expense_comment" value="{{ old('expense_comment') }}"></td>
                          <td></td>
                          <td class="p-0 align-middle"><button type="submit" class="btn btn-link p-0" title="Add record"><i class="far fa-plus-square fa-2x text-success"></i></button></td>
                        </tr>
                      @endif
                    </table>
                    
                    <!-- Display expense errors -->
                    @if ($errors->has('expense_description') || $errors->has('expense_amount'))
                      @foreach ($errors->all() as $error)
                        <p class="mt-1 mb-0 text-danger">{{ $error }}</p>
                      @endforeach
                    @endif
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Delete confirmation modal -->
<div class="modal" id="deleteModal" style="display:none">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="formModal" method="POST" action="">
      @method('DELETE')
      @csrf

      <div class="modal-header">
        <h4 class="modal-title">Confirmation</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body">
        Delete this record?
      </div>

      <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="submit()">Yes</button>
        <button type="button" class="btn btn-success" data-dismiss="modal">No</button>
      </div>

      </form>
    </div>
  </div>
</div>


<script>
  function deleteClicked(income_id, expense_id) {
    formModal.action = "/home/" + income_id + "/" + expense_id;
  }
</script>
@endsection
