<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Income;
use App\Expenses;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($income_id = 0, $expense_id = 0)
    {
        $incomes = Income::orderBy('income_amount', 'desc')->get();
        $income_total = Income::sum('income_amount');
        
        $expenses = Expenses::orderBy('expense_amount', 'desc')->get();
        $expense_total = Expenses::sum('expense_amount');
        
        return view('home', compact('incomes', 'income_id', 'income_total', 'expenses', 'expense_id', 'expense_total'));
    }    
        
    /**
     * Store an income or expense record
     *
     * @return \Illuminate\Http\Response
     */
    public function store($type)
    {
        if ($type == 'income') {  // income
            $this->validate(request(), [
                'income_description' => 'required',
                'income_amount' => 'numeric'
            ]);
        
            $success = Income::create(request(['income_description', 'income_amount', 'income_comment']));
            
        } else {  // expense
            $this->validate(request(), [
                'expense_description' => 'required',
                'expense_amount' => 'numeric'
            ]);
        
            $success = Expenses::create(request(['expense_description', 'expense_amount', 'expense_comment']));
        }
        
        if ($success) {
            return redirect('/home');
        } else {
            return redirect()->back()->withInput(request()->all);
        }
    }
    
    /**
     * Update an income or expense record
     *
     * @return \Illuminate\Http\Response
     */
    public function update()
    {
        if (request('income_oldid')) {  // income
            $this->validate(request(), [
                'income_description' => 'required',
                'income_amount' => 'numeric'
            ]);
        
            Income::find(request('income_oldid'))->update(request(['income_description', 'income_amount', 'income_comment']));
            
        } else {  // expense
            $this->validate(request(), [
                'expense_description' => 'required',
                'expense_amount' => 'numeric'
            ]);
        
            Expenses::find(request('expense_oldid'))->update(request(['expense_description', 'expense_amount', 'expense_comment']));
        }
        
        return redirect('/home');
    }
    
    /**
     * Delete an income or expense record
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($income_id = 0, $expense_id = 0)
    {
        if ($income_id) {
            Income::find($income_id)->delete();
        } else {
            Expenses::find($expense_id)->delete();
        }
        
        return redirect('/home');
    }
}
