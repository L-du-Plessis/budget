<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Income;
use App\Expenses;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($income_id = 0, $expense_id = 0)
    {
        $incomes = Income::orderBy('income_amount', 'desc')->get();
        $income_total = Income::sum('income_amount');
        
        $expenses = Expenses::orderBy('expense_amount', 'desc')->get();
        $expense_total = Expenses::sum('expense_amount');
        
        return view('home', compact('incomes', 'income_id', 'income_total', 'expenses', 'expense_id', 'expense_total'));
    }    
    
    /**
     * Store an income record
     *
     */
    public function storeIncome()
    {
        $this->validate(request(), [
            'income_description' => 'required',
            'income_amount' => 'numeric'
        ]);
        
        if (request()->income_oldid) {  // update record
            Income::find(request()->income_oldid)->update([
                'income_description' => request()->income_description,
                'income_amount' => request()->income_amount,
                'income_comment' => request()->income_comment
            ]);
            
            return redirect('/home');
        } else {  // new record
            $success = Income::create(request(['income_description', 'income_amount', 'income_comment']));
        
            if ($success) {
                return redirect('/home');
            } else {
                return redirect()->back()->withInput(request()->all);
            }
        }
    }
    
    /**
     * Store an expense record
     *
     */
    public function storeExpense()
    {
        $this->validate(request(), [
            'expense_description' => 'required',
            'expense_amount' => 'numeric'
        ]);
        
        if (request()->expense_oldid) {  // update record
            Expenses::find(request()->expense_oldid)->update([
                'expense_description' => request()->expense_description,
                'expense_amount' => request()->expense_amount,
                'expense_comment' => request()->expense_comment
            ]);
            
            return redirect('/home');
        } else {  // new record
            $success = Expenses::create(request(['expense_description', 'expense_amount', 'expense_comment']));
        
            if ($success) {
                return redirect('/home');
            } else {
                return redirect()->back()->withInput(request()->all);
            }
        }
    }
    
    /**
     * Delete an income or expense record
     *
     */
    public function destroy($income_id = 0, $expense_id = 0)
    {
        if ($income_id) {
            Income::find($income_id)->delete();
        } else {
            Expenses::find($expense_id)->delete();
        }
        
        return redirect('/home');
    }
}
